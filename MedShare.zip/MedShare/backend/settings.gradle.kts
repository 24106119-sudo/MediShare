rootProject.name = "medishare-backend"
